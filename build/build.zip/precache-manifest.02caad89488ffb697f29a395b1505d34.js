self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f9d5ca2afa16ec1c4552bdfa5bd5e5e4",
    "url": "/index.html"
  },
  {
    "revision": "d53dda2a3f00a2e42c13",
    "url": "/static/css/main.d1b05096.chunk.css"
  },
  {
    "revision": "80437b595e8c7bee8c26",
    "url": "/static/js/2.383a84e2.chunk.js"
  },
  {
    "revision": "6f5f1c4a5f7f6e382b8aeca1b4ac8d96",
    "url": "/static/js/2.383a84e2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d53dda2a3f00a2e42c13",
    "url": "/static/js/main.ffc81938.chunk.js"
  },
  {
    "revision": "464c8a6eee638933db9f",
    "url": "/static/js/runtime-main.c83a4d79.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);